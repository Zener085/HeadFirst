This is my first library for Python. HeadFirst helps me to do this, I hope I'd do this so fast and correct.
It's created by Zener.085